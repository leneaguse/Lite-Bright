Project Title: LITE-BRITE
Your Name: Lenea Guse
Team Members: William Antonio
Youtube Link: https://www.youtube.com/watch?v=9vicqJg4Dds 

Project Instructions: 	Our project is intended to mock the game lite brite. In our game, the player 
			can place and pick up colored "pegs" in order to draw a picture of their
			desire. There is no winner, it's just a creative outlet for the user.

My role in the project: I mostly worked on getting the color wheel to work in order for the user to 
			be able to rotate between several colors to use and programmed the top LEDs
			to be different colors. During lab time as well, I assisted with bugs that
			came up in the program or other trivial parts of the code. I also worked 
			with Will to create the flowchart and the video for the project.


Workload Breakdown:    Will wrote a good chunk of the code since I struggled with writing in C. I did
			however help any time there was challenging parts of the code and I wrote the
			method for the user to be able to choose a color for the program. I would say
			workload was about 40% for me and 60% for Will. While he did write a lot of
			code, I gave him a lot of input of what I think should happen with the code and
			helped with challenging parts or any bugs that came up.			

What I learned from the project: For this project, I learned a lot about the basics of of using C to
			program. It also really helped me understand how different user inputs can be
			used by the program code to do really unique things. 

Suggestions:   		Coming into this class, I was really hoping to focus on hardware rather than coding
			of electronics. I think it would be really nice to spend half the semester working 
			on hardware and the other half on coding the hardware.

