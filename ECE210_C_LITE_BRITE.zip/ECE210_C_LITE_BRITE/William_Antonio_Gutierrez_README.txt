Project Title: C LITE BRITE
Your Name:William Antonio-Gutierrez
Team Members:Lenea Guse
Youtube Link:	https://youtu.be/9vicqJg4Dds

Project Instructions: <Use this area to describe what your project does,
		       and what someone would need to know to use your project>
			   Program C LITE BRITE is a drawing app that allows you to choose from a set 
	number of colors with right button to go forward in the list
	and left button to go back in the list of colors. Colors are displaced on the screen 
	in a cursor dotthat can be moved around with the joystick.
				Color of cursor can be placed by pressing up button and colors placed can be erased by hovering 
	cursor over and pressing button down.
			

My role in the project: <Use this area to describe what YOU did for the project as a whole,
			i.e, I worked on the part of code that intepreted the RSSI signal
			and converted it to distance to an invisible badger. >
			I contributed with the brainstorming process as well as a majority of the coding of the program.
			All members put in effort and care on the development of the program.

Workload Breakdown:    <Evaluate the contributions of your team members to the success of 
			the project. If Johnny wrote a piece of good code that made the project 
			possible, give his work some acknowledgment. Evaluate, percentage-wise,
			how much each student contributed to the project as a whole.>	
				Good teamwork dynamic. All members contributed and made great efforts to make the project possible.
				50 / 50 contributions.

What I learned from the project: <Use this area to describe what YOU gained from working on
			this project.  What kind of concepts learned in lab helped you with
			your project? > 
			I had no experience coding with C language and thanks to this class I now have a better understanding 
			of both software and hardware. This class was a good intro overall. Sometimes it felt too advanced on 
			a good portion of the class relied on background information of signals, C programming, and use of 
			digital multimeters and advanced tools of the like.

Suggestions:   <Make at least one suggestion about what you would like added to or changed about
		the class if you were to take it again, or some advice you would like to pass on to
		a future student taking this class> 
		More soldering and hands on electronics(hardware). less coding.

